package ObjetosSerializables;
/**
 * 
 * @author luiiis
 *
 */
public class Estimacion {

	String idestimacion;
	String idfrente;
	String idConsultor;
	String pocentaje;
	String fecha;
	String tipo;
	String nestimacion;

	/**
	 * 
	 * @param idestimacion
	 */
	public void setIdestimacion(String idestimacion) {
		this.idestimacion = idestimacion;
	}

	/**
	 * 
	 * @return
	 */
	public String getIdestimacion() {
		return this.idestimacion;
	}

	/**
	 * 
	 * @param idfrente
	 */
	public void setIdfrente(String idfrente) {
		this.idfrente = idfrente;
	}

	/**
	 * 
	 * @return
	 */
	public String getIdfrente() {
		return this.idfrente;
	}

	/**
	 * 
	 * @param idConsultor
	 */
	public void setIdConsultor(String idConsultor) {
		this.idConsultor = idConsultor;
	}

	/**
	 * 
	 * @return
	 */
	public String getIdconsultor() {
		return this.idConsultor;
	}

	/**
	 * 
	 * @param porcentaje
	 */
	public void setPorcentaje(String porcentaje) {
		this.pocentaje = porcentaje;
	}

	/**
	 * 
	 * @return
	 */
	public String getPorcentaje() {
		return this.pocentaje;
	}

	/**
	 * 
	 * @param fecha
	 */
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	/**
	 * 
	 * @return
	 */
	public String getFecha() {
		return this.fecha;
	}

	/**
	 * 
	 * @param tipo
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * 
	 * @return
	 */
	public String getTipo() {
		return this.tipo;
	}

	/**
	 * 
	 * @param nestimacion
	 */
	public void setNestimacion(String nestimacion) {
		this.nestimacion = nestimacion;
	}

	/**
	 * 
	 * @return
	 */
	public String getNestimacion() {
		return this.nestimacion;
	}
}
