package ObjetosSerializables;

/**
 * 
 * @author luiiis
 *
 */
public class Objetoexecel {

	private String titulo;
	private String guion;
	private String clave;
	private String descripcion;
	private String unidad;
	private String costo;

	/**
	 * 
	 * @param titulo
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	/**
	 * 
	 * @return
	 */
	public String getTitulo() {
		return this.titulo;
	}

	/**
	 * 
	 * @param guion
	 */
	public void setGuion(String guion) {
		this.guion = guion;
	}

	/**
	 * 
	 * @return
	 */
	public String getGuion() {
		return this.guion;
	}

	/**
	 * 
	 * @param clave
	 */
	public void setClave(String clave) {
		this.clave = clave;
	}

	/**
	 * 
	 * @return
	 */
	public String getClave() {
		return this.clave;
	}

	/**
	 * 
	 * @param descripcion
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * 
	 * @return
	 */
	public String getDescripcion() {
		return this.descripcion;
	}

	/**
	 * 
	 * @param unidad
	 */
	public void setUnidad(String unidad) {
		this.unidad = unidad;
	}

	/**
	 * 
	 * @return
	 */
	public String getUnidad() {
		return this.unidad;
	}

	/**
	 * 
	 * @param costo
	 */
	public void setCosto(String costo) {
		this.costo = costo;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getCosto() {
		return this.costo;
	}
}
