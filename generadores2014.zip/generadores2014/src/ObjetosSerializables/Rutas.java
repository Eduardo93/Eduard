package ObjetosSerializables;

/**
 * 
 * @author luiiis
 *
 */
public class Rutas {

	private String uno;
	private String dos;

	/**
	 * 
	 * @param uno
	 */
	public void setUno(String uno) {
		this.uno = uno;
	}

	/**
	 * 
	 * @return
	 */
	public String getUno() {
		return this.uno;
	}

	/**
	 * 
	 * @param dos
	 */
	public void setDos(String dos) {
		this.dos = dos;
	}

	/**
	 * 
	 * @return
	 */
	public String getDos() {
		return this.dos;
	}
}
