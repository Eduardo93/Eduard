package Model.EntityCRUD.Exceptions;

public class ErrorUnexpected extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ErrorUnexpected() {
		super ("Ha Ocurrido un Error Inesperado");
	}

}
